const express = require('express');
const GarbagePointController = require('../controllers/GarbagePoint.controller');

const router = express.Router();
const garbagePointController = new GarbagePointController();

router.get('/', garbagePointController.getAllGarbagePoints.bind(garbagePointController));
router.post('/', garbagePointController.createGarbagePoint.bind(garbagePointController));
router.get('/:id', garbagePointController.getGarbagePointById.bind(garbagePointController));
router.delete('/:id', garbagePointController.deleteGarbagePointById.bind(garbagePointController));
router.put('/:id', garbagePointController.updateGarbagePointById.bind(garbagePointController));

module.exports = router;
