const express = require('express');
const IssueController = require('../controllers/Issue.controller');
const { body } = require('express-validator');
const router = express.Router();
const issueController = new IssueController();

router.post('/', [
    // Validate request body
    body('title').notEmpty(),
    body('description').optional(),
    body('location').notEmpty().isObject(),
    body('status').optional(),
    body('image').optional(),
  ], issueController.createIssue.bind(issueController));
router.get('/', issueController.getAllIssues.bind(issueController));
router.get('/:id', issueController.getIssueById.bind(issueController));
router.delete('/:id', issueController.deleteIssueById.bind(issueController));
router.put('/:id', issueController.updateIssueById.bind(issueController));

module.exports = router;
