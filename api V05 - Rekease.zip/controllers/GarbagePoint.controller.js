const GarbagePointService = require('../services/GarbagePoints.service');

class GarbagePointController {
  constructor() {
    this.garbagePointService = new GarbagePointService();
  }

  async getAllGarbagePoints(req, res) {
    try {
      const garbagePoints = await this.garbagePointService.getAllGarbagePoints();
      res.json(garbagePoints);
    } catch (error) {
      res.status(500).json({ error: error.message });
    }
  }

  async createGarbagePoint(req, res) {
    try {
      const newGarbagePoint = await this.garbagePointService.createGarbagePoint(req.body);
      res.status(201).json(newGarbagePoint);
    } catch (error) {
      res.status(400).json({ error: error.message });
    }
  }

  async getGarbagePointById(req, res) {
    try {
      const garbagePoint = await this.garbagePointService.getGarbagePointById(req.params.id);
      res.json(garbagePoint);
    } catch (error) {
      res.status(404).json({ error: 'Garbage Point not found' });
    }
  }

  async deleteGarbagePointById(req, res) {
    try {
      await this.garbagePointService.deleteGarbagePointById(req.params.id);
      res.sendStatus(204);
    } catch (error) {
      res.status(404).json({ error: 'Garbage Point not found' });
    }
  }

  async updateGarbagePointById(req, res) {
    try {
      const updatedGarbagePoint = await this.garbagePointService.updateGarbagePointById(req.params.id, req.body);
      res.json(updatedGarbagePoint);
    } catch (error) {
      res.status(404).json({ error: 'Garbage Point not found' });
    }
  }
}

module.exports = GarbagePointController;
