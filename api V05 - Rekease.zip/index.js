const express = require('express');
const dotenv = require('dotenv');
const cors = require('cors');
const {readdirSync} = require('fs');
const { db } = require('./configs/configs');
dotenv.config()

const garbagePointRoute = require('./routes/GarbagePoint.route')
const issuesRoute = require('./routes/Issues.route')
const userRoute = require('./routes/Users.route')
const authRoute = require('./routes/Auth.route')
const notificationRoute = require('./routes/Notifications.route')

const app = express();
const port = process.env.PORT || 5001;

// CORS
app.use(express.json())
app.use(cors())



// Define routes
app.get('/', (req, res) => {
    res.send('App is Running!');
});

app.use("/api/garbage-point", garbagePointRoute);
app.use("/api/users", userRoute);
app.use("/api/issues", issuesRoute);
app.use("/api/auth", authRoute);
app.use("/api/notifications", notificationRoute);

// Start the server
const server = () => {
    db();
    app.listen(port, () => {
        console.log(`Server is running on port ${port}`);
    });
}

server()
