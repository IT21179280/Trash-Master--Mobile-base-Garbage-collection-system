const mongoose = require('mongoose');

// Schema for Garbage Points
const garbagePointSchema = new mongoose.Schema({
  address: {
    type: String,
    required: true
  },
  coordinates: {
    type: [Number], 
    required: true
  },
  approved: {
    type: Boolean,
    default: false 
  },
  schedule: {
    type: [{
      day: String, 
      collectionTime: String 
    }],
    default: [] 
  }
});

const GarbagePoint = mongoose.model('GarbagePoint', garbagePointSchema);

module.exports = GarbagePoint;
