const GarbagePoint = require('../models/GarbagePoint');

class GarbagePointService {
  async getAllGarbagePoints() {
    return await GarbagePoint.find();
  }

  async createGarbagePoint(garbagePointData) {
    return await GarbagePoint.create(garbagePointData);
  }

  async getGarbagePointById(id) {
    return await GarbagePoint.findById(id);
  }

  async deleteGarbagePointById(id) {
    return await GarbagePoint.findByIdAndDelete(id);
  }

  async updateGarbagePointById(id, updateData) {
    return await GarbagePoint.findByIdAndUpdate(id, updateData, { new: true });
  }
}

module.exports = GarbagePointService;
