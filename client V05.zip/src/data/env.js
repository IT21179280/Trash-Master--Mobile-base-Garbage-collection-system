const env = {
    SERVER_URL: 'http://localhost:5000',
    SECTORS:  [
        "Colombo 01", "Homagama", "Horana"
    ]
}

export default env