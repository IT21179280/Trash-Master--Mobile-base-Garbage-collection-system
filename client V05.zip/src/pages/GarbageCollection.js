import React, { useState } from 'react';
import { GoogleMap, LoadScript, Marker } from '@react-google-maps/api';
import Navigation from '../components/nav/Navigation';
import Footer from '../components/footer/Footer';
import markerIcon from '../data/images/garbage.png';
import Notiflix from 'notiflix';
import IssuesService from '../services/Issues.service';
import { Button } from 'react-bootstrap';
import { useNavigate } from 'react-router-dom';

const GarbageCollectionForm = () => {
  const navigate = useNavigate();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState({ lat: 0, lng: 0 });
  const [image, setImage] = useState(null);
  const [prediction, setPrediction] = useState(null);

  const mapStyles = {
    height: '400px',
    width: '100%'
  };

  const defaultCenter = {
    lat: 7.8731, lng: 80.7718
  };

  const handleTitleChange = (e) => {
    setTitle(e.target.value);
  };

  const handleDescriptionChange = (e) => {
    setDescription(e.target.value);
  };

  const handleMapClick = (event) => {
    // Extract lat and lng from the event
    const lat = event.latLng.lat();
    const lng = event.latLng.lng();
    // Update the location state
    setLocation({ lat, lng });
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setImage(file);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if ((title === '')) {
      Notiflix.Report.failure(
        'Title is required',
        'Title is required for a issue',
        'Okay',
      );
      return;
    }

    if ((location.lat === 0)) {
      Notiflix.Report.failure(
        'Location is required',
        'Location is required for a issue',
        'Okay',
      );
      return;
    }

      const formData = new FormData();
      formData.append('file', image);
      formData.append('upload_preset', 'gtnnidje'); 

      try {
        const response = await fetch('https://api.cloudinary.com/v1_1/dkox7lwxe/image/upload', {
          method: 'POST',
          body: formData,
        });

        const cloudinaryData = await response.json();

        let obj = {
          title,
          description,
          location,
          image: cloudinaryData.secure_url,
        }

        await IssuesService.addIssue(obj).then(() => {
          Notiflix.Report.success(
            'Success',
            'Issue Recorded successfully!',
            'Okay',
          );
        })
      }
      catch (error) {
        console.error('Error uploading image to Cloudinary:', error);
        Notiflix.Notify.failure('Error uploading image. Please try again.');
      }

    
  };

  const checkImage = async () => {
    if (!image) {
      Notiflix.Notify.warning('Please select an image first.');
      return;
    }

    const formData = new FormData();
    formData.append('file', image);

    try {
      const response = await fetch('http://localhost:8000/predictGarbageType', {
        method: 'POST',
        body: formData
      });

      const data = await response.json();
      setPrediction(data.prediction);
      setDescription(description+ ' '+data.prediction);
    } catch (error) {
      console.error('Error predicting garbage type:', error);
      Notiflix.Notify.failure('Error predicting garbage type. Please try again.');
    }
  };

  return (
    <div className="garbage-collection-form-container"> {/* Apply container styles */}
      <Navigation />
      <div className='form-container'>
        <h2>Garbage Collection Form </h2>
        <a className="mr-3 from-button" style={{cursor:'pointer'}} onClick={() => {
                navigate('/map');
                window.location.reload();
              }}>Visit Full Map</a>
              <br/><br/>
        <form onSubmit={handleSubmit}>
          <div>
            <label>Title:</label>
            <input type="text" value={title} onChange={handleTitleChange} />
          </div>
          <div>
            <label>Description:</label>
            <textarea value={description} onChange={handleDescriptionChange} />
          </div>
          <div>
            <label>Mark Your Location:</label>
            <LoadScript googleMapsApiKey={'AIzaSyDAsJYZSQ92_NQAz9kiSpW1XpyuCxRl_uI'}>
              <GoogleMap
                mapContainerStyle={mapStyles}
                zoom={10}
                center={defaultCenter}
                onClick={handleMapClick}
              >
                {location && <Marker position={{lat: 7.8731, lng: 80.7718}}  />}
                {/* <Marker position={{lat: 7.8731, lng: 80.7718}}  /> */}
                
              </GoogleMap>
            </LoadScript>
            <div>
              <h4>Coordinates:</h4>
              <p>Latitude: {location.lat}</p>
              <p>Longitude: {location.lng}</p>
            </div>
          </div>

          <br></br>
          <div>
            <label>Upload Image:</label>
            <input type="file" onChange={handleImageChange} />
          </div>
          <div>
            {image && (
              <div className="image-preview-card">
                <img src={URL.createObjectURL(image)} alt="Preview" className="image-preview" />
                <div className="image-details">
                  <h3>Image Preview:</h3>
                  <Button variant='secondary' onClick={checkImage}>Check Image</Button> <br/>
                  {prediction && <p>Prediction: {prediction}</p>}
                </div>
              </div>
            )}
          </div>
          <br></br>
          <button className='form-button' type="submit">Submit</button>
          <br/>
          
        </form>
      </div>
      <Footer />
    </div>
  );
};

export default GarbageCollectionForm;
