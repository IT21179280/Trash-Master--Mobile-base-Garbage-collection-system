import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Notiflix from 'notiflix';
import usersService from '../services/Users.service';
import env from '../data/env';
import EventEmitter from '../utils/EventEmitter';


const Signup = () => {
  const navigate = useNavigate();
  const [userRole, setUserRole] = useState('');
  const [speciality, setSpeciality] = useState('');
  const [qualifications, setQualifications] = useState([]);
  const [name, setName] = useState('');
  const [nic, setNic] = useState('');
  const [sector, setSector] = useState('Colombo 01');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [email, setEmail] = useState('');
  const [contactNumber, setContactNumber] = useState('');
  const [avatar, setAvatar] = useState(null);

  const handleUserRoleChange = (e) => {
    setUserRole(e.target.value);
  };

  const handleAreaahange = (e) => {
    setSector(e.target.value);
  };

  const handleAddQualification = (qualification) => {
    if (qualification && !qualifications.includes(qualification)) {
      setQualifications([...qualifications, qualification]);
    }
  };

  const handleRemoveQualification = (index) => {
    const updatedQualifications = qualifications.filter((_, i) => i !== index);
    setQualifications(updatedQualifications);
  };

  const handleSignUp = async () => {
    console.log(username)
      if ((userRole === '')) {
        Notiflix.Report.failure(
          'Registration Failed',
          'UserRole is required for Registration',
          'Okay',
        );
        return;
      }
      if ((username === '')) {
        Notiflix.Report.failure(
          'Registration Failed',
          'Username required for Registration',
          'Okay',
        );
        return;
      }
      if ((nic === '')) {
        Notiflix.Report.failure(
          'Registration Failed',
          'NIC number required for Registration',
          'Okay',
        );
        return;
      } else if (nic.length !== 10 && nic.length !== 12) {
        Notiflix.Report.failure(
          'Registration Failed',
          'NIC number should be either 10 or 12 characters long',
          'Okay',
        );
        return;
      }
      if ((email === '' || contactNumber === null)) {
        Notiflix.Report.failure(
          'Registration Failed',
          'Email and Contact number required for Registration',
          'Okay',
        );
        return;
      }
      if ((password === '')) {
        Notiflix.Report.failure(
          'Registration Failed',
          'Password can not be empty',
          'Okay',
        );
        return;
      }
      if (!(password === confirmPassword)) {
        Notiflix.Report.failure(
          'Registration Failed',
          'Password doesn\'t match with confirmation password',
          'Okay',
        );
        return;
      }

      // Cloudinary Upload
      const formData = new FormData();
      formData.append('file', avatar);
      formData.append('upload_preset', 'gtnnidje'); 

      try {
        const response = await fetch('https://api.cloudinary.com/v1_1/dkox7lwxe/image/upload', {
          method: 'POST',
          body: formData,
        });

        const cloudinaryData = await response.json();

        if (userRole === 'user') {
          let obj = {
            username: username,
            fullName: name,
            nic: nic,
            email: email,
            contact: contactNumber,
            password: password,
            section: sector,
            role: userRole,
            avatar: cloudinaryData.secure_url,
          };

          await usersService.addUser(obj).then(() => {
            Notiflix.Report.success(
              'Success',
              'Registration Successful as a Citizen',
              'Okay',
            );
            navigate('/sign-in');
            // window.location.reload();
          });
        } else if (userRole === 'garbage collector') {
          let obj = {
            username: username,
            fullName: name,
            nic: nic,
            email: email,
            contact: contactNumber,
            role: userRole,
            section: sector,
            password: password,
            avatar: cloudinaryData.secure_url,
          };

          await usersService.addUser(obj).then(() => {
            
            // window.location.reload();
          }).catch(() => {
            Notiflix.Notify.failure('Provided email is already being using.');
          });
        }
      } catch (error) {
        console.error('Error uploading image to Cloudinary:', error);
        Notiflix.Notify.failure('Error uploading image. Please try again.');
      }
    
  };

  useEffect(() => {
    let listner = EventEmitter.addListener("registerCompleted", () => {
      Notiflix.Report.success(
        'Success',
        'Registration Successful as Garbage Collector',
        'Okay',
      );
      navigate('/sign-in');
    });
    let listner2 = EventEmitter.addListener("registerFailed", () => {
      Notiflix.Notify.failure('Provided email is already being using.');
    });

    return () => {
      listner.remove();
      listner2.remove();
    }
  }, [])

  return (
    <div className='form-body'>
    <div className="max-w-md mx-auto mt-8 p-6 bg-white rounded-md shadow-md container">
      <h2 className="text-2xl font-semibold mb-4">Sign Up</h2>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          User Role
        </label>
        <select
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:border-blue-500"
          onChange={handleUserRoleChange}
        >
          <option value="">Select User Role</option>
          <option value="user">Citizen</option>
          <option value="garbage collector">Garbage Collector</option>
        </select>
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Your Area / Sector
        </label>
        <select
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:border-blue-500"
          onChange={handleAreaahange}
        >
          <option value="">Select Sector</option>
          {env.SECTORS.map((item) => <option value={item}>{item}</option>)}
        </select>
      </div>

      {/* Common Inputs */}
      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Full Name
        </label>
        <input
          type="text"
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:border-blue-500"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          NIC Number
        </label>
        <input
          type="text"
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:border-blue-500"
          value={nic}
          onChange={(e) => setNic(e.target.value)}
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Username
        </label>
        <input
          type="text"
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:border-blue-500"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
      </div>

      {['Garbage Collector'].includes(userRole) && (
        <div className="mb-4">
          <label className="block text-gray-700 text-sm font-bold mb-2">
            Specialize In
          </label>
          <div className="flex items-center">
            <input
              type="text"
              id='qualifi'
              className="flex-1 px-4 py-2 border rounded-md focus:outline-none focus:border-blue-500"
              placeholder="Add Qualification"
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleAddQualification(e.target.value);
                  e.target.value = '';
                }
              }}
            />
            <button
              className="ml-2 bg-blue-500 text-white py-2 px-4 rounded-md hover:bg-blue-600 focus:outline-none"
              onClick={() => {
                const input = document.querySelector('#qualifi');
                if (input) {
                  handleAddQualification(input.value);
                  input.value = '';
                }
              }}
            >
              Add
            </button>
          </div>
          <div className="mt-2 space-x-2">
            {qualifications.map((qualification, index) => (
              <div
                key={index}
                className="inline-flex items-center bg-gray-200 rounded-full px-3 py-1 text-sm font-semibold text-gray-700"
              >
                {qualification}
                <button
                  className="ml-2 text-red-500 hover:text-red-600 focus:outline-none"
                  onClick={() => handleRemoveQualification(index)}
                >
                  X
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* ... Other role-specific inputs ... */}

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Email
        </label>
        <input
          type="email"
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:border-blue-500"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Contact Number
        </label>
        <input
          type="text"
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:border-blue-500"
          value={contactNumber}
          onChange={(e) => setContactNumber(e.target.value)}
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Password
        </label>
        <input
          type="password"
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:border-blue-500"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Confirm Password
        </label>
        <input
          type="password"
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:border-blue-500"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
        />
      </div>

      <div className="mb-4">
        <label className="block text-gray-700 text-sm font-bold mb-2">
          Avatar (Upload)
        </label>
        <input
          type="file"
          className="w-full px-4 py-2 border rounded-md focus:outline-none focus:border-blue-500"
          onChange={(e) => setAvatar(e.target.files[0])}
        />
      </div>

      {/* Submit Button */}
      <button
        className="w-full bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600 focus:outline-none form-button"
        onClick={handleSignUp}
      >
        Sign Up
      </button>
      <p className="mt-4 text-sm text-gray-600">
        Don't have an account?{' '}
        <Link to="/sign-in" className="font-medium text-indigo-600 hover:text-indigo-500">
          Sign In
        </Link>
      </p>
    </div>
    </div>
  );
};

export default Signup;
