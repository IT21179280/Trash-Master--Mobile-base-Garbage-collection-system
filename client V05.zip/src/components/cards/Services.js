import React from 'react';
import ServiceCard from './ServiceCard';
import './card.css'
import { Col } from 'react-bootstrap';

const Services = () => {
  const servicesData = [
    {
      title: "Garbage Collection Points",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam accumsan euismod lorem, eget consectetur felis accumsan a.",
      buttonText: "Learn More",
      image: "/bin2.png"
    },
    {
      title: "Collection Services",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam accumsan euismod lorem, eget consectetur felis accumsan a.",
      buttonText: "Learn More",
      image: "/truck.png"
    },
    {
      title: "Notification Service",
      description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam accumsan euismod lorem, eget consectetur felis accumsan a.",
      buttonText: "Learn More",
      image: "/notification.png"
    }
  ];

  return (
    <div className="services-container">
        <Col className="text-center">
          
            <h1>Services We Provide</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam accumsan euismod lorem.</p>
        </Col>
      <div className="row">
        {servicesData.map((service, index) => (
          <div className="col-lg-4 col-md-6" key={index}>
            <ServiceCard title={service.title} description={service.description} buttonText={service.buttonText} image={service.image}/>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Services;
