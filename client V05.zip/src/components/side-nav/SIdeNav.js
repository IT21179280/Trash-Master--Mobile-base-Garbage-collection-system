// SideNavBar.js
import React, { useState } from "react";
import "@trendmicro/react-sidenav/dist/react-sidenav.css";
import { AiOutlineUser, AiOutlineUserSwitch, AiOutlineAlert, AiOutlineHome, AiOutlineNotification } from 'react-icons/ai'
import SideNav, { Toggle, Nav, NavItem, NavIcon, NavText } from "@trendmicro/react-sidenav";
import { Link } from "react-router-dom";

const SideNavBar = ({onToggle}) => {
  const [isVisible, setIsVisible] = useState(false);

  const handleToggle = () => {
    const newVisibility = !isVisible;
    setIsVisible(newVisibility);
    onToggle(newVisibility); // Call the callback function to notify Dashboard
  };

  return (
    <SideNav expanded={isVisible} style={{ background: 'var(--primary-bg)' }}>
      <SideNav.Toggle
        onClick={() => {
          handleToggle();
        }}
      />
      <SideNav.Nav defaultSelected="home">
        <NavItem eventKey="home">
          <NavIcon>
            <Link to={'/dashboard'}><AiOutlineUser style={{ fontSize: "1.75em" }} /></Link>
          </NavIcon>
          <NavText><Link to={'/dashboard'}>Profile</Link></NavText>
        </NavItem>
        {localStorage.getItem('role')==='garbage collector'&&<NavItem eventKey="users">
          <NavIcon>
            <Link to={'/dashboard/users-management'}><AiOutlineUserSwitch style={{ fontSize: "1.75em" }} /></Link>
          </NavIcon>
          <NavText><Link to={'/dashboard/users-management'}>Users Management</Link></NavText>
        </NavItem>}
        {localStorage.getItem('role')==='garbage collector'&&<NavItem eventKey="issues">
          <NavIcon>
            <Link to={'/dashboard/issues-management'}><AiOutlineAlert style={{ fontSize: "1.75em" }} /></Link>
          </NavIcon>
          <NavText><Link to={'/dashboard/issues-management'}>Issues Management</Link></NavText>
        </NavItem>}
        {localStorage.getItem('role')==='garbage collector'&&<NavItem eventKey="notifications">
          <NavIcon>
            <Link to={'/dashboard/notifications'}><AiOutlineNotification style={{ fontSize: "1.75em" }} /></Link>
          </NavIcon>
          <NavText><Link to={'/dashboard/notifications'}>Notifications</Link></NavText>
        </NavItem>}
        <NavItem eventKey="index">
          <NavIcon>
            <Link to={'/'}><AiOutlineHome style={{ fontSize: "1.75em" }} /></Link>
          </NavIcon>
          <NavText><Link to={'/'}>To Home</Link></NavText>
        </NavItem>
      </SideNav.Nav>
    </SideNav>
  );
};

export default SideNavBar;
