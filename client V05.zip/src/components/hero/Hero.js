import React from 'react';
import { Container, Row, Col, Button } from 'react-bootstrap';
import './hero.css';
import { Link, useNavigate } from 'react-router-dom';

const HeroContainer = () => {
  const navigate = useNavigate();
  return (
    <div className="hero-container">
      <Container fluid>
        <Row className="align-items-center"> {/* Vertically center content */}
          <Col className="text-center">
            <h1>Welcome to Our Website</h1>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam accumsan euismod lorem, eget consectetur felis accumsan a.</p>
            <div className="button-group">
              <Button variant="primary" className="mr-3" onClick={() => {
                navigate('/map');
                window.location.reload();
              }}>Visit Map</Button>
              <Link to={'/sign-in'}><Button variant="secondary">Login</Button></Link>
            </div>
          </Col>
        </Row>
      </Container>
    </div>
  );
};

export default HeroContainer;
