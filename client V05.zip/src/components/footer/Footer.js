import React from 'react';
import './footer.css'; 

const Footer = () => {
  return (
    <footer className="mfooter">
      <div className="footer-column logo-column" style={{ flex: 2 }}>
        <div className="logo">
          <img src={require('./bin1.png')} height={150}/>
        </div>
        <div className="contact-info">
          Contact Information<br/>Tel: +94 (011 345 4353) <br/>
          Email: garbage.col@gv.gov
        </div>
      </div>
      <div className="footer-column" style={{ flex: 1 }}>
        {/* Second column for links */}
        <div className="footer-links">
          <h3>Links</h3>
          <ul>
            <li>Terms and Condirions</li>
            <li>Community Guidelines</li>
            <li>RSS</li>
          </ul>
        </div>
      </div>
      <div className="footer-column" style={{ flex: 1 }}>
        {/* Third column for additional links */}
        <div className="footer-links">
          <h3>More Links</h3>
          <ul>
            <li>ICTA</li>
            <li>Other Links</li>
          </ul>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
