import './App.css';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import MapWindow from './pages/MapWindow';
import Signup from './pages/SignUp';
import SignIn from './pages/SignIn';
import GarbageCollectionForm from './pages/GarbageCollection';
import Home from './pages/Home';
import Profile from './pages/dashboard/Profile';
import UsersManagement from './pages/dashboard/UsersManagement';
import IssuesManagement from './pages/dashboard/IssuesManagement';
import Notifications from './pages/dashboard/Notifications';
import AboutUs from './pages/AboutUs';
import PageNotFound from './pages/PageNotFound';

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route element={<Home/>} path='/' />
          <Route element={<MapWindow/>} path='/map' />
          <Route element={<GarbageCollectionForm/>} path='/garbage-collection' />
          <Route element={<AboutUs/>} path='/aboutus' />
          <Route element={<Signup/>} path='/sign-up' />
          <Route element={<SignIn/>} path='/sign-in' />
          <Route  path='/dashboard' >
            <Route element={<Profile/>} path='' />
            <Route element={<UsersManagement/>} path='users-management' />
            <Route element={<IssuesManagement/>} path='issues-management' />
            <Route element={<Notifications/>} path='notifications' />
          </Route>
          <Route path='*' element={<PageNotFound />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;
